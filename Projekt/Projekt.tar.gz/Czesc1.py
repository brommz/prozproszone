import random
from MergeSortMultiprocess import MergeSortMultiprocess

def main():
    # uzytkownik ustala wielkosc tablicy i liczbe procesow
    N = int(raw_input('Podaj wielkosc tablicy: '))
    procNumber = int(raw_input('Podaj maksymalna liczbe procesow: '))

    # generujemy losowa tablice
    array = [random.randint(1, 1000) for x in range(N)]

    tester = MergeSortMultiprocess()
    sortedArray = tester.testMergeSort(array, procNumber)

    print("Tablica: ", array)
    print("Tablica posortowana: ", sortedArray)

if __name__ == '__main__':
    main()